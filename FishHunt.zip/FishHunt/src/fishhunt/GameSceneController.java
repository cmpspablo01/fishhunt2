package fishhunt;

import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javafx.animation.*;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author Pablo
 */
public class GameSceneController implements Initializable {

    @FXML
    private AnchorPane game_background;
    @FXML
    private Label score;
    @FXML
    private ImageView life1;
    @FXML
    private ImageView life2;
    @FXML
    private ImageView life3;
    @FXML
    private Label level;
    @FXML
    private Label game_over;
    private Circle circle;
    private double centerX, centerY;
    private int scoreInt = 0;
    private int levelInt = 0;
    private ArrayList<String> normalFish;
    private ArrayList<Color> colorList;
    private String crabe, star;
    private ImageView fish;
    private int lives = 3;
    // Déterminer si le jouer à cliquer sur le poisson
    private boolean clicked = false;
    private Timer gameTimer, levelTimer;
    public static Stage stage;
    private Scene scene;
    private Parent root;
    // Déterminer si le joueur a gagné
    //Si le joueur gagne on ignore le clique
    private boolean won = false;
    //sfTimer = SpecialFishTimer
    private Timeline sfTimer;
    private Timeline sbTimer;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        setFishnColorList();
        showLevel();
        specialFishTimer();
        sendBubbles();
    }

    public void specialFishTimer() {
        //sfTimer = SpecialFishTimer
        sfTimer = new Timeline(new KeyFrame(Duration.seconds(5), this::sendSpecialFish));
        sfTimer.setCycleCount(Timeline.INDEFINITE);
    }

    public void sendBubbles() {
        //sfTimer = SpecialFishTimer
        sbTimer = new Timeline(new KeyFrame(Duration.seconds(5), this::sendBubbles));
        sbTimer.setCycleCount(Timeline.INDEFINITE);
        sbTimer.play();
    }

    public void sendSpecialFish(ActionEvent e) {
        if (!won) {
            // Si le joueur n'a pas encore gagné on commence à envoyer des poissons spéciaux
            // https://stackoverflow.com/questions/363681/how-do-i-generate-random-integers-within-a-specific-range-in-java
            // Source pour avoir un numéro aléatoire
            String[] specialFish = {"fishhunt/crabe.png", "fishhunt/star.png"};
            Random rand = new Random();
            int randomStart = rand.nextInt((((4 * 480) / 5) - (480 / 5)) + 1) + (480 / 5);
            //Une chance de 50% des crabes ou des etoiles
            int randomSpecialFish = (int) Math.round(Math.random());
            ImageView sFish = new ImageView(new Image(specialFish[randomSpecialFish]));
            sFish.setFitHeight(115);
            sFish.setFitWidth(115);

            sFish.setX(-40);
            sFish.setY(randomStart);

            game_background.getChildren().add(sFish);

            TranslateTransition t = new TranslateTransition();

            sFish.setOnMouseClicked((MouseEvent mEvent) -> {
                if (!won) {
                    sFish.setVisible(false);
                    scoreInt++;
                    score.setText(scoreInt + "");
                    if (scoreInt % 5 == 0) {
                        won = true;
                        showLevel();
                    }
                }
            });

            // Le mouvement des Poissions Speciaux
            // Pourquoi on doit cliquer plusieurs fois ?????
            // Les bulles en background !!!!!!
            int[] upOrDown = {60, -60};
            int randomPath = rand.nextInt((1) + 1);

            t.setDuration(Duration.millis(2000));
            t.setNode(sFish);

            t.setByX(750);
            t.play();
        }
    }

    public void sendBubbles(ActionEvent e) {
        if (!won) {
            //Envoie des bulles

            circle = new Circle();
            Circle circle1 = new Circle();
            Circle circle2 = new Circle();
            circle.setFill(Color.WHITE);
            circle.setStroke(Color.GREY);
            circle.setRadius(10);
            circle1.setFill(Color.WHITE);
            circle1.setStroke(Color.GREY);
            circle1.setRadius(10);
            circle2.setFill(Color.WHITE);
            circle2.setStroke(Color.GREY);
            circle2.setRadius(10);

            circle.setCenterX(120);
            circle.setCenterY(480);
            circle1.setCenterX(130);
            circle1.setCenterY(465);
            circle2.setCenterX(140);
            circle2.setCenterY(480);

            game_background.getChildren().add(circle);
            game_background.getChildren().add(circle1);
            game_background.getChildren().add(circle2);

            TranslateTransition t = new TranslateTransition();
            t.setByY(-480);
            t.setDuration(Duration.millis(5000));
            t.setNode(circle);
            TranslateTransition t2 = new TranslateTransition();
            t2.setByY(-480);
            t2.setDuration(Duration.millis(5000));
            t2.setNode(circle1);
            TranslateTransition t3 = new TranslateTransition();
            t3.setByY(-480);
            t3.setDuration(Duration.millis(5000));
            t3.setNode(circle2);

            t.play();
            t2.play();
            t3.play();

            t.setOnFinished(f -> {
                game_background.getChildren().remove(circle);
            });
            
            t2.setOnFinished(f -> {
                game_background.getChildren().remove(circle1);
            });
            
            t3.setOnFinished(f -> {
                game_background.getChildren().remove(circle2);
            });
        }
    }

    public void showLevel() {
        levelInt++;
        level.setText("Level " + levelInt);
        level.setVisible(true);
        levelTimer = new Timer();

        levelTimer.schedule(new ShowLevelTimer(), 3000);

        gameTimer = new Timer();
    }

    public void MouseClicked(MouseEvent e) {
        clickAnimation(e);
    }

    private void clickAnimation(MouseEvent e) {
        circle = new Circle();
        circle.setFill(Color.BLACK);
        circle.setStroke(Color.BLACK);

        game_background.getChildren().add(circle);

        circle.setCenterX(e.getSceneX() + 16);
        circle.setCenterY(e.getSceneY() + 16);
        circle.setRadius(25);

        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    Thread.sleep(15);
                    circle.setRadius(15);
                    Thread.sleep(15);
                    circle.setVisible(false);
                    Platform.runLater(new Runnable() {

                        @Override
                        public void run() {
                            game_background.getChildren().remove(circle);
                        }

                    });
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        }).start();

    }

    private void sendFish() {
        clicked = false;
        // Generate random number to get a Random Normal Fish
        // https://stackoverflow.com/questions/363681/how-do-i-generate-random-integers-within-a-specific-range-in-java
        // Source pour avoir un numéro aléatoire
        Random rand = new Random();
        int randomNormalFish = rand.nextInt((7) + 1);
        int randomColor = rand.nextInt((4) + 1);
        // Avoir un numéro aléatoire pour définir l'effet qui sera appliquer sur l'image
        // Colorize, Flip ou Flop
        int randomEffect = rand.nextInt((2) + 1);
        //Differencier le point de départ des poissons
        int randomSide = rand.nextInt((1) + 1);
        // Depart aleatoire entre 1/5 et 4/5 de la hauteur
        int randomStart = rand.nextInt((((4 * 480) / 5) - (480 / 5)) + 1) + (480 / 5);

        Image image;

        //Utiliser les differents effets
        switch (randomEffect) {
            case 0:
                image = ImageHelpers.colorize(new Image("fishhunt/" + normalFish.get(randomNormalFish)), colorList.get(randomColor));
                break;
            case 1:
                image = ImageHelpers.flip(new Image("fishhunt/" + normalFish.get(randomNormalFish)));
                break;
            default:
                image = ImageHelpers.flop(new Image("fishhunt/" + normalFish.get(randomNormalFish)));
                break;
        }

        fish = new ImageView(image);
        fish.setFitHeight(115);
        fish.setFitWidth(115);

        if (randomSide == 0) {
            fish.setX(640);
            fish.setY(randomStart);
        } else {
            fish.setX(-40);
            fish.setY(randomStart);
        }

        game_background.getChildren().add(fish);

        TranslateTransition t = new TranslateTransition();

        fish.setOnMouseClicked((MouseEvent e) -> {
            if (!won) {
                fish.setVisible(false);
                clicked = true;
                scoreInt++;
                score.setText(scoreInt + "");
                if (scoreInt % 5 == 0) {
                    won = true;
                    showLevel();
                }
            }
        });

        int[] upOrDown = {60, -60};
        int randomPath = rand.nextInt((1) + 1);

        // 200 Px/s et en divisant 1000 Par le niveau
        // Le jeu accélera au fur et à mésure
        int vitesse = 1000 / (levelInt * 3) + 200;

        t.setDuration(Duration.seconds(3));
        t.setNode(fish);
        if (randomSide == 0) {
            t.setByX(-750);
        } else {
            t.setByX(750);
        }

        t.setByY(50);

        t.setOnFinished(e -> {
            if (!won) {
                if (clicked) {
                    System.out.println("clicked");
                    //t.stop();
                    sendFish();
                } else {
                    System.out.println("not clicked");
                    fish.setVisible(false);
                    lives--;
                    switch (lives) {
                        case 2:
                            life3.setVisible(false);
                            break;
                        case 1:
                            life2.setVisible(false);
                            break;
                        case 0:
                            life1.setVisible(false);
                    }
                    if (lives > 0) {
                        sendFish();
                    } else {
                        gameOver();
                    }
                }
            } else {
                //Derniere modification !!!!!!
                fish.setVisible(false);
            }
        });

        t.play();
    }

    private void setFishnColorList() {
        colorList = new ArrayList<>();
        normalFish = new ArrayList<>();

        normalFish.add("00.png");
        normalFish.add("01.png");
        normalFish.add("02.png");
        normalFish.add("03.png");
        normalFish.add("04.png");
        normalFish.add("05.png");
        normalFish.add("06.png");
        normalFish.add("07.png");

        colorList.add(Color.RED);
        colorList.add(Color.GREEN);
        colorList.add(Color.PURPLE);
        colorList.add(Color.ORANGE);
        colorList.add(Color.PINK);

        crabe = "crabe.png";
        star = "star.png";
    }

    private void gameOver() {
        game_over.setVisible(true);
        FishHunt.gameSceneToBestScores = scoreInt;
        Timer gameOverTimer = new Timer();
        // On Affiche Game Over pendant 3 secondes
        // Avant de passer à l'écran suivante
        gameOverTimer.schedule(new GameOver(), 3000);
        // On arrete le Special Fish Timer
        sfTimer.stop();
    }

    private class GameOver extends TimerTask {

        public GameOver() {
        }

        @Override
        public void run() {
            Platform.runLater(new Runnable() {

                @Override
                public void run() {
                    try {
                        root = FXMLLoader.load(getClass().getResource("BestScores.fxml"));
                        stage = (Stage) game_over.getScene().getWindow();
                        scene = new Scene(root);
                        stage.setScene(scene);
                        // on empeche l'utilisateur de modifier la taille de la fenetre
                        stage.setResizable(false);
                        stage.show();
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                }

            });
        }
    }

    private class ShowLevelTimer extends TimerTask {

        public ShowLevelTimer() {
        }

        @Override
        public void run() {
            won = true;
            level.setVisible(false);
            gameTimer.schedule(new StartGame(), 3000);

            //Si le Niveau est supérieur ou égale à 2
            // On commencer à envoyer les poissons spéciaux
            if (levelInt >= 2) {
                sfTimer.play();
            }
        }
    }

    private class StartGame extends TimerTask {

        public StartGame() {
        }

        @Override
        public void run() {
            Platform.runLater(new Runnable() {

                @Override
                public void run() {
                    try {
                        won = false;
                        sendFish();
                    } catch (Exception e) {

                    }
                }
            });

        }
    }
}
