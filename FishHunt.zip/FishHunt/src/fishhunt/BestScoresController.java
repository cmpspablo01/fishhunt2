package fishhunt;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Pablo
 */
public class BestScoresController implements Initializable {

    @FXML
    private AnchorPane scores_background;
    @FXML
    private ListView<String> scores_liste;
    @FXML
    private Button menu_button;
    @FXML
    private Button ajouter;
    @FXML
    private Label name_label;
    @FXML
    private Label score_label;
    @FXML
    private TextField score_name;

    private Stage stage;
    private Scene scene;
    private Parent root;
    private int score = 0;

    private HashMap<Integer, String> scoresList;
    private ObservableList<String> scoresToAddToList;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Verifier si le joueur vient de la Scene du Jeu
        // ou bien du Menu Principal
        if (FishHunt.gameSceneToBestScores != -1) {
            //Afficher et enregistrer les informations du joueur
            score = FishHunt.gameSceneToBestScores;
            showNregister();
        }

        // La méthode utilisé pour obtenir les meilleurs scores du fichier txt
        getScores();

        // On remet la valeur à -1
        FishHunt.gameSceneToBestScores = -1;
    }

    private void getScores() {
        try {
            File f = new File("scores.txt");
            // Si le fichier existe déjà veut dire qu'il contient des scores
            if (f.exists()) {
                scoresList = new HashMap<>();
                scoresToAddToList = FXCollections.observableArrayList();
                Scanner sc = new Scanner(f);
                while (sc.hasNext()) {
                    String tmp[] = sc.nextLine().split(":");
                    scoresList.put(Integer.parseInt(tmp[0]), tmp[1]);
                }

                ArrayList<Integer> scoresToSort = new ArrayList<>();

                scoresToSort.addAll(scoresList.keySet());

                // Trier la liste du Grand score au petit
                Collections.sort(scoresToSort, Collections.reverseOrder());

                for (int i = 0; i < scoresToSort.size(); i++) {
                    scoresToAddToList.add("#" + (i + 1) + " - " + scoresList.get(scoresToSort.get(i)) + " - " + scoresToSort.get(i));
                }

                scores_liste.setItems(scoresToAddToList);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showNregister() {
        ajouter.setVisible(true);
        name_label.setVisible(true);
        score_label.setVisible(true);
        score_name.setVisible(true);

        score_label.setText("a fait " + score + " points!");
    }

    @FXML
    private void backToMenu(ActionEvent event) throws IOException {
        // Revenir au menu principal
        Parent root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        // on empeche l'utilisateur de modifier la taille de la fenetre
        stage.setResizable(false);
        stage.show();
    }

    @FXML
    private void addScore(ActionEvent event) throws Exception {
        // Ajouter un score au fichier
        if (score_name.getText().length() == 0) {
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Ajouter un Nom");
            alert.setHeaderText("Ajouter un nom pour enregister votre score");
            alert.showAndWait().ifPresent(rs -> {
                if (rs == ButtonType.OK) {
                    System.out.println("Compris.");
                }
            });
        } else {
            File f = new File("scores.txt");
            //Créer le fichier s'il n'existe pas
            if (!f.exists()) {
                f.createNewFile();
            }
            // pour ne pas créer un nouveau fichier on doit autoriser APPEND
            // En mettant TRUE comme argument
            PrintStream ps = new PrintStream(new FileOutputStream(f,true));
            ps.println(score + ":" + score_name.getText());

            // Revenir au menu principal après l'ajout de résultat
            Parent root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            // on empeche l'utilisateur de modifier la taille de la fenetre
            stage.setResizable(false);
            stage.show();
        }

    }
}